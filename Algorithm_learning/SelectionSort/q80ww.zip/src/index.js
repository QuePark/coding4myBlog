import "./styles.css";

document.getElementById("app").innerHTML = `
<h1>Hello Vanilla!</h1>
<div>
  We use the same configuration as Parcel to bundle this sandbox, you can find more
  info about Parcel 
  <a href="https://parceljs.org" target="_blank" rel="noopener noreferrer">here</a>.
</div>
`;

// 목적 : 선택 정렬을 만들자!
// 1. Random하게 번호를
// n 배열 생성
// random number 호출

//선택 정렬 = 작은 숫자부터 큰 숫자까지 정렬;
// 함수 실행

const generateNumber = function (max) {
  return Math.floor(Math.random() * max);
};

const makeArr = function (num) {
  const result = [];
  for (let i = 0; i < num; i++) {
    result.push(generateNumber(num * 5));
  }
  return result;
};

// 선택 정렬을 해야 함
// 이중 for 문을 가동
// 가장 작은 숫자를 찾는다. Swap을 하는 함수가 필요
// [30, 345, 22, 203, 123, 44, 33, 23, 99, 100]
// swap 함수를 호출한다고 생각하고 진행을 해라...
// arr[i]와 arr[j]가 같은 경우 continue
// minValue < arr[j] => minValue가

const swap = function (a, b) {
  const tmp = a;
  a = b;
  b = tmp;
};

const insertSort = function (arr) {
  let min = Infinity;
  let flag = 0;
  for (let i = 0; i < arr.length - 1; i++) {
    for (let j = i + 1; j < arr.length - 1; j++) {
      if (min > arr[j]) {
        min = arr[j];
        flag = j;
      }
    }
    if (arr[flag] < arr[i]) {
      swap(arr[flag], arr[i]);
    }
  }
};

const init = function () {
  debugger;
  const span = document.createElement("span");
  const randomArr = makeArr(10);
  console.log(randomArr);
  insertSort(randomArr);
  console.log(randomArr);
  document.querySelector("#app").append((span.textContent = `${randomArr}`));
};

init();